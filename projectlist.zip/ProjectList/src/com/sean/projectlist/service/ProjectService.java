package com.sean.projectlist.service;

import java.util.List;

import com.sean.projectlist.dao.ProjectDAO;
import com.sean.projectlist.entity.Project;

//工程业务逻辑处理类
public class ProjectService {
	//获取所有工程列表
	public List<Project> getProjectList() {
		try {
			//声明工程信息数据访问对象
			ProjectDAO projectDAO = new ProjectDAO();
			//获取工程信息列表
			return projectDAO.findAll();
		} catch (Exception e) {
			//出错时，先打印出错信息
			e.printStackTrace();
			//然后返回 null
			return null;
		}
	}

}
