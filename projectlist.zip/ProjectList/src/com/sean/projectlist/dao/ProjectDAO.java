package com.sean.projectlist.dao;

import java.sql.DriverManager;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.sean.projectlist.entity.Project;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

//工程信息访问类
public class ProjectDAO {
	//声明并初始化 JDBC 驱动参数
	private String driver = "com.mysql.jdbc.Driver";
	//声明并初始化 JDBC 连接参数
	private String url = 
		"jdbc:mysql://localhost:3306/ConstructionDB?characterEncoding=utf8";
	//声明并初始化 JDBC 用户名参数
	private String user = "root";
	//声明并初始化 JDBC 密码参数
	private String password = "password";
	
	//获取所有工程信息列表
	public List<Project> findAll() {
		//声明并初始化 JDBC 连接对象
		Connection conn = null;
		//声明并初始化 JDBC PreparedStatement 对象
		PreparedStatement prepStat = null;
		//声明并初始化 JDBC 结果集对象
		ResultSet rs = null;

		//声明并初始化从数据库中提取项目信息的 SQL 语句
		String sql = "select * from T_project";

		try {
			//加载驱动
			Class.forName(driver);
			//获取连接
			conn = DriverManager.getConnection(url, user, password);
			//获取 PreparedStatement
			prepStat = conn.prepareStatement(sql);
			
			//声明并初始化工程信息列表
			List<Project> projectList = new ArrayList<Project>();
			
			//执行数据库查询，获取所有的工程信息记录
			rs = prepStat.executeQuery();
			//遍历结果集
			while (rs.next()) {
				//把结果集中的一行存放到工程信息对象里
				Project project = new Project(
						rs.getString("Project_id"),
						rs.getString("Project_name"),
						rs.getString("Deputy_name"), 
						rs.getString("Telephone"),
						rs.getString("Addr"));
				//把工程信息对象添加到列表里
				projectList.add(project);
			}
			
			//返回工程信息列表
			return projectList;			
		} catch (Exception e) {
			//出错时，先打印出错信息
			e.printStackTrace();
			//然后返回 null
			return null;
		} finally {
			//释放结果集资源
			try {
				if (null!=rs) rs.close();
			} catch (Exception e) {

			}

			//释放 PreparedStatement 资源
			try {
				if (null!=prepStat) prepStat.close();
			} catch (Exception e) {

			}

			//释放连接资源
			try {
				if (null!=conn) conn.close();
			} catch (Exception e) {

			}
		}
	}
}
