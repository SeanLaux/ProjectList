package com.sean.projectlist.entity;

public class Project {
	//声明工程编号变量
	private String projectId;
	//声明工程名称变量
	private String projectName;
	//声明法人代表变量
	private String deputyName;
	//声明电话变量
	private String telephone;
	//声明地址变量
	private String add;
	
	//包含所有成员变量的构造函数	
	public Project(String projectId, String projectName, String deputyName, String telephone, String add) {
		super();
		this.projectId = projectId;
		this.projectName = projectName;
		this.deputyName = deputyName;
		this.telephone = telephone;
		this.add = add;
	}

	//每个成员变量的存取方法
	
	public String getProjectId() {
		return projectId;
	}

	public void setProjectId(String projectId) {
		this.projectId = projectId;
	}

	public String getProjectName() {
		return projectName;
	}

	public void setProjectName(String projectName) {
		this.projectName = projectName;
	}

	public String getDeputyName() {
		return deputyName;
	}

	public void setDeputyName(String deputyName) {
		this.deputyName = deputyName;
	}

	public String getTelephone() {
		return telephone;
	}

	public void setTelephone(String telephone) {
		this.telephone = telephone;
	}

	public String getAdd() {
		return add;
	}

	public void setAdd(String add) {
		this.add = add;
	}
}
