package com.sean.projectlist.servlet;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sean.projectlist.entity.Project;
import com.sean.projectlist.service.ProjectService;

/**
 * Servlet implementation class CProjectServlet
 */
@WebServlet("/ProjectServlet")
public class ProjectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ProjectServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request,
	 *  HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) 
					throws ServletException, IOException {
		try {
			//声明工程业务逻辑处理对象
			ProjectService projectService = new ProjectService();
			//获取工程信息列表
			List<Project> projectList = 
					projectService.getProjectList();
			//把工程信息列表存放到 request 里
			request.setAttribute("projectList", projectList);
			//再转到工程信息列表页面
			request.getRequestDispatcher("project_list.jsp")
			.forward(request, response);
		} catch (Exception e) {
			//出错时，先打印出错信息
			e.printStackTrace();
			//再转到错误处理页面
			request.getRequestDispatcher("error.html")
			.forward(request, response);
		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}
